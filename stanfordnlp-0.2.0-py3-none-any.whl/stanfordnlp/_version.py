""" Single source of truth for version number """

__version__ = "0.2.0"
