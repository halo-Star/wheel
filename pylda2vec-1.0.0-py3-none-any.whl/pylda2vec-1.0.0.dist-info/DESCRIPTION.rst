# lda2vec

-----

**Table of Contents**

* [Installation](#installation)
* [License](#license)

## Installation

lda2vec is distributed on [PyPI](https://pypi.org) as a universal
wheel and is available on Linux/macOS and Windows and supports
Python 3.6+.

```bash
$ pip install lda2vec
```

## License

lda2vec is distributed under the terms of the
[MIT License](https://choosealicense.com/licenses/mit).


